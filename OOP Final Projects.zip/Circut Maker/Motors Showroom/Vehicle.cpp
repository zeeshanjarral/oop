// Vehicle.cpp

#include "Vehicle.h"
#include <cstring>
#include <iostream>

Vehicle::Vehicle(const char* companyName, const char* color, int numberOfWheels,
                 int powerCC, const char* typeOfVehicle)
    : companyName(new char[strlen(companyName) + 1]), color(new char[strlen(color) + 1]),
      numberOfWheels(numberOfWheels), powerCC(powerCC), typeOfVehicle(new char[strlen(typeOfVehicle) + 1]) {
    strcpy(this->companyName, companyName);
    strcpy(this->color, color);
    strcpy(this->typeOfVehicle, typeOfVehicle);
}

Vehicle::~Vehicle() {
    delete[] companyName;
    delete[] color;
    delete[] typeOfVehicle;
}

void Vehicle::display() const {
    std::cout << "Company: " << companyName << "\nColor: " << color << "\nWheels: " << numberOfWheels
              << "\nPower CC: " << powerCC << "\nType: " << typeOfVehicle << std::endl;
}

const char* Vehicle::getCompanyName() const {
    return companyName;
}

const char* Vehicle::getColor() const {
    return color;
}

int Vehicle::getNumberOfWheels() const {
    return numberOfWheels;
}

int Vehicle::getPowerCC() const {
    return powerCC;
}

const char* Vehicle::getTypeOfVehicle() const {
    return typeOfVehicle;
}

void Vehicle::setCompanyName(const char* companyName) {
    delete[] this->companyName;
    this->companyName = new char[strlen(companyName) + 1];
    strcpy(this->companyName, companyName);
}

void Vehicle::setColor(const char* color) {
    delete[] this->color;
    this->color = new char[strlen(color) + 1];
    strcpy(this->color, color);
}

void Vehicle::setNumberOfWheels(int numberOfWheels) {
    this->numberOfWheels = numberOfWheels;
}

void Vehicle::setPowerCC(int powerCC) {
    this->powerCC = powerCC;
}

void Vehicle::setTypeOfVehicle(const char* typeOfVehicle) {
    delete[] this->typeOfVehicle;
    this->typeOfVehicle = new char[strlen(typeOfVehicle) + 1];
    strcpy(this->typeOfVehicle, typeOfVehicle);
}

Vehicle& Vehicle::operator=(const Vehicle& other) {
    if (this != &other) {
        setCompanyName(other.getCompanyName());
        setColor(other.getColor());
        setNumberOfWheels(other.getNumberOfWheels());
        setPowerCC(other.getPowerCC());
        setTypeOfVehicle(other.getTypeOfVehicle());
    }
    return *this;
}
