// main.cpp

#include "BilalMotors.h"
#include <iostream>

void ShowVehicles(const BilalMotors& bilalMotors);

int main() {
    BilalMotors bilalMotors;

    char option;
    do {
        std::cout << "\n*** BILAL MOTORS ***\n"
                  << "S Show vehicles list (brief)\n"
                  << "E Create a data file (output file)\n"
                  << "A Add new vehicle\n"
                  << "B for Bike\n"
                  << "C for Car\n"
                  << "F Find Vehicle by type\n"
                  << "Q Quit Program\n"
                  << "Enter option: ";
        std::cin >> option;

        switch (option) {
            case 'S':
                ShowVehicles(bilalMotors);
                break;

            case 'E':
                // Add code to create a data file
                break;

            case 'A':
                // Add code to add a new vehicle
                break;

            case 'B':
                // Add code to add a new bike
                break;

            case 'C':
                // Add code to add a new car
                break;

            case 'F':
                // Add code to find vehicles by type
                break;

            case 'Q':
                std::cout << "Exiting the program.\n";
                break;

            default:
                std::cout << "Invalid option. Please try again.\n";
        }

    } while (option != 'Q');

    return 0;
}

void ShowVehicles(const BilalMotors& bilalMotors) {
    std::cout << "\nNumber of Total Vehicles: " << bilalMotors.getNumVehicles() << "\n"
              << "--------------------------------------------------------------------\n";
    for (int i = 0; i < bilalMotors.getNumVehicles(); ++i) {
        bilalMotors[i]->display();
        std::cout << "--------------------------------------------------------------------\n";
    }
}
