// Bike.cpp

#include "Bike.h"
#include <iostream>

Bike::Bike(const char* companyName, const char* color, int numberOfWheels,
           int powerCC, const char* typeOfVehicle, double height,
           bool selfStart, bool discBrake)
    : Vehicle(companyName, color, numberOfWheels, powerCC, typeOfVehicle),
      height(height), selfStart(selfStart), discBrake(discBrake) {}

Bike::~Bike() {}

void Bike::checkType() const {
    // Assume all vehicles with 2 wheels are bikes
    std::cout << "This is a Bike." << std::endl;
}

void Bike::display() const {
    Vehicle::display();
    std::cout << "Height: " << height << "\nSelf Start: " << (selfStart ? "Yes" : "No")
              << "\nDisc Brake: " << (discBrake ? "Yes" : "No") << std::endl;
}

double Bike::getHeight() const {
    return height;
}

bool Bike::hasSelfStart() const {
    return selfStart;
}

bool Bike::hasDiscBrake() const {
    return discBrake;
}

void Bike::setHeight(double height) {
    this->height = height;
}

void Bike::setSelfStart(bool selfStart) {
    this->selfStart = selfStart;
}

void Bike::setDiscBrake(bool discBrake) {
    this->discBrake = discBrake;
}

Bike& Bike::operator=(const Bike& other) {
    if (this != &other) {
        Vehicle::operator=(other);
        setHeight(other.getHeight());
        setSelfStart(other.hasSelfStart());
        setDiscBrake(other.hasDiscBrake());
    }
    return *this;
}
