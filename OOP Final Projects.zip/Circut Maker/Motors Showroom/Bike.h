// Bike.h

#ifndef BIKE_H
#define BIKE_H

#include "Vehicle.h"

class Bike : public Vehicle {
private:
    double height;
    bool selfStart;
    bool discBrake;

public:
    Bike(const char* companyName = "", const char* color = "", int numberOfWheels = 2,
         int powerCC = 0, const char* typeOfVehicle = "", double height = 0.0,
         bool selfStart = false, bool discBrake = false);

    ~Bike();

    void checkType() const override;

    void display() const override;

    double getHeight() const;

    bool hasSelfStart() const;

    bool hasDiscBrake() const;

    void setHeight(double height);

    void setSelfStart(bool selfStart);

    void setDiscBrake(bool discBrake);

    Bike& operator=(const Bike& other);
};

#endif
