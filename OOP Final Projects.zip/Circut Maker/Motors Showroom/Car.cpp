// Car.cpp

#include "Car.h"
#include <iostream>

Car::Car(const char* companyName, const char* color, int numberOfWheels,
         int powerCC, const char* typeOfVehicle, int noOfDoors,
         const char* transmission, int noOfSeats)
    : Vehicle(companyName, color, numberOfWheels, powerCC, typeOfVehicle),
      noOfDoors(noOfDoors), transmission(new char[strlen(transmission) + 1]),
      noOfSeats(noOfSeats) {
    strcpy(this->transmission, transmission);
}

Car::~Car() {
    delete[] transmission;
}

void Car::checkType() const {
    // Assume all vehicles with 4 wheels are cars
    std::cout << "This is a Car." << std::endl;
}

void Car::display() const {
    Vehicle::display();
    std::cout << "Number of Doors: " << noOfDoors << "\nTransmission: " << transmission
              << "\nNumber of Seats: " << noOfSeats << std::endl;
}

int Car::getNoOfDoors() const {
    return noOfDoors;
}

const char* Car::getTransmission() const {
    return transmission;
}

int Car::getNoOfSeats() const {
    return noOfSeats;
}

void Car::setNoOfDoors(int noOfDoors) {
    this->noOfDoors = noOfDoors;
}

void Car::setTransmission(const char* transmission) {
    delete[] this->transmission;
    this->transmission = new char[strlen(transmission) + 1];
    strcpy(this->transmission, transmission);
}

void Car::setNoOfSeats(int noOfSeats) {
    this->noOfSeats = noOfSeats;
}

Car& Car::operator=(const Car& other) {
    if (this != &other) {
        Vehicle::operator=(other);
        setNoOfDoors(other.getNoOfDoors());
        setTransmission(other.getTransmission());
        setNoOfSeats(other.getNoOfSeats());
    }
    return *this;
}
