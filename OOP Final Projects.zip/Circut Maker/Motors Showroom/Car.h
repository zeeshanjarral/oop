// Car.h

#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"

class Car : public Vehicle {
private:
    int noOfDoors;
    char* transmission;
    int noOfSeats;

public:
    Car(const char* companyName = "", const char* color = "", int numberOfWheels = 4,
        int powerCC = 0, const char* typeOfVehicle = "", int noOfDoors = 0,
        const char* transmission = "", int noOfSeats = 0);

    ~Car();

    void checkType() const override;

    void display() const override;

    int getNoOfDo
