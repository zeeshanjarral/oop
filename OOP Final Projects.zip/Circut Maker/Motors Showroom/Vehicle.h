// Vehicle.h

#ifndef VEHICLE_H
#define VEHICLE_H

class Vehicle {
private:
    char* companyName;
    char* color;
    int numberOfWheels;
    int powerCC;
    char* typeOfVehicle;

public:
    Vehicle(const char* companyName = "", const char* color = "", int numberOfWheels = 0,
            int powerCC = 0, const char* typeOfVehicle = "");

    virtual ~Vehicle();

    virtual void checkType() const = 0;

    virtual void display() const;

    const char* getCompanyName() const;

    const char* getColor() const;

    int getNumberOfWheels() const;

    int getPowerCC() const;

    const char* getTypeOfVehicle() const;

    void setCompanyName(const char* companyName);

    void setColor(const char* color);

    void setNumberOfWheels(int numberOfWheels);

    void setPowerCC(int powerCC);

    void setTypeOfVehicle(const char* typeOfVehicle);

    Vehicle& operator=(const Vehicle& other);
};

#endif
