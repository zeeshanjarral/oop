#include <iostream>
#include <string>

class Product {
public:
    Product(const std::string& name, double price, int quantity);
    virtual ~Product();

    virtual void displayDetails() const;
    virtual Product& operator=(const Product& other);
    virtual void processOrder(int orderedQuantity);

protected:
    std::string name;
    double price;
    int quantityInStock;
};

