#include "Product.h"

class ElectronicsProduct : public Product {
public:
    ElectronicsProduct(const std::string& name, double price, int quantity, const std::string& brand);
    void displayDetails() const override;
    Product& operator=(const Product& other) override;
    void processOrder(int orderedQuantity) override;

private:
    std::string brand;
};

