// Product.cpp

#include "Product.h"

Product::Product(const std::string& name, double price, int quantity)
    : name(name), price(price), quantityInStock(quantity) {}

Product::~Product() {}

void Product::displayDetails() const {
    std::cout << "Name: " << name << "\nPrice: Rs" << price << "\nQuantity in Stock: " << quantityInStock << std::endl;
}

Product& Product::operator=(const Product& other) {
    if (this != &other) {
        name = other.name;
        price = other.price;
        quantityInStock = other.quantityInStock;
    }
    return *this;
}

void Product::processOrder(int orderedQuantity) {
    if (orderedQuantity <= quantityInStock) {
        std::cout << "Order processed successfully. Quantity updated." << std::endl;
        quantityInStock -= orderedQuantity;
    } else {
        std::cout << "Insufficient quantity in stock. Order not processed." << std::endl;
    }
}
