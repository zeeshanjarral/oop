#include <iostream>
#include "Product.h"
#include "ElectronicsProduct.h"
#include "ClothingProduct.h"

int main() {
    // Get user input for ElectronicsProduct
    std::string electronicName, electronicBrand;
    double electronicPrice;
    int electronicQuantity;
    std::cout << "Enter Electronics Product Name: ";
    std::cin >> electronicName;
    std::cout << "Enter Electronics Product Price: Rs";
    std::cin >> electronicPrice;
    std::cout << "Enter Electronics Product Quantity: ";
    std::cin >> electronicQuantity;
    std::cout << "Enter Electronics Product Brand: ";
    std::cin >> electronicBrand;

    // Create instance of ElectronicsProduct
    ElectronicsProduct laptop(electronicName, electronicPrice, electronicQuantity, electronicBrand);

    // Get user input for ClothingProduct
    std::string clothingName, clothingSize;
    double clothingPrice;
    int clothingQuantity;
    std::cout << "\nEnter Clothing Product Name: ";
    std::cin >> clothingName;
    std::cout << "Enter Clothing Product Price: Rs";
    std::cin >> clothingPrice;
    std::cout << "Enter Clothing Product Quantity: ";
    std::cin >> clothingQuantity;
    std::cout << "Enter Clothing Product Size: ";
    std::cin >> clothingSize;

    // Create instance of ClothingProduct
    ClothingProduct shirt(clothingName, clothingPrice, clothingQuantity, clothingSize);

    // Display details for each product using base class pointer polymorphically
    std::cout << "\nProduct Details:" << std::endl;

    // Using base class pointer polymorphically
    Product* ptr1 = &laptop;
    ptr1->displayDetails();

    std::cout << "\nProduct Details:" << std::endl;

    // Using base class pointer polymorphically
    Product* ptr2 = &shirt;
    ptr2->displayDetails();

    // Process orders for each product
    int orderQuantity;
    std::cout << "\nEnter Order Quantity for Laptop: ";
    std::cin >> orderQuantity;
    ptr1->processOrder(orderQuantity);

    std::cout << "Enter Order Quantity for Shirt: ";
    std::cin >> orderQuantity;
    ptr2->processOrder(orderQuantity);

    // Use assignment operator and display copied product details
    ElectronicsProduct copiedLaptop("Copied Laptop", 0.0, 0, "");
    ClothingProduct copiedShirt("Copied Shirt", 0.0, 0, "");

    copiedLaptop = laptop;
    copiedShirt = shirt;

    std::cout << "\nCopied Laptop Details:" <<
