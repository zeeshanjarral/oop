#include "ClothingProduct.h"

ClothingProduct::ClothingProduct(const std::string& name, double price, int quantity, const std::string& size)
    : Product(name, price, quantity), size(size) {}

void ClothingProduct::displayDetails() const {
    Product::displayDetails();
    std::cout << "Size: " << size << std::endl;
}

Product& ClothingProduct::operator=(const Product& other) {
    if (this != &other) {
        Product::operator=(other);
        const ClothingProduct& otherClothing = dynamic_cast<const ClothingProduct&>(other);
        size = otherClothing.size;
    }
    return *this;
}

void ClothingProduct::processOrder(int orderedQuantity) {
    // Specific processing for ClothingProduct
    Product::processOrder(orderedQuantity);
    // Additional processing for ClothingProduct if needed
}
