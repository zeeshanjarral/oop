#include "Product.h"

class ClothingProduct : public Product {
public:
    ClothingProduct(const std::string& name, double price, int quantity, const std::string& size);
    void displayDetails() const override;
    Product& operator=(const Product& other) override;
    void processOrder(int orderedQuantity) override;

private:
    std::string size;
};

