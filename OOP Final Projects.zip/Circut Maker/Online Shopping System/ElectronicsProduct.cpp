// ElectronicsProduct.cpp

#include "ElectronicsProduct.h"

ElectronicsProduct::ElectronicsProduct(const std::string& name, double price, int quantity, const std::string& brand)
    : Product(name, price, quantity), brand(brand) {}

void ElectronicsProduct::displayDetails() const {
    Product::displayDetails();
    std::cout << "Brand: " << brand << std::endl;
}

Product& ElectronicsProduct::operator=(const Product& other) {
    if (this != &other) {
        Product::operator=(other);
        const ElectronicsProduct& otherElectronics = dynamic_cast<const ElectronicsProduct&>(other);
        brand = otherElectronics.brand;
    }
    return *this;
}

void ElectronicsProduct::processOrder(int orderedQuantity) {
    // Specific processing for ElectronicsProduct
    Product::processOrder(orderedQuantity);
    // Additional processing for ElectronicsProduct if needed
}
