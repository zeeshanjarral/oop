// main.cpp

#include "ShipFactory.h"
#include <iostream>

int main() {
    const int arraySize = 8;
    Ship* ships[arraySize];

    // Create ships using the ShipFactory
    ships[0] = ShipFactory::createShip("Ship1", new Date(2000), 500);  // Container Ship
    ships[1] = ShipFactory::createShip("Ship2", new Date(2010), 1000); // Container Ship
    ships[2] = ShipFactory::createShip("Ship3", new Date(2015), 200);  // Cruise Ship
    ships[3] = ShipFactory::createShip("Ship4", new Date(2020), 300);  // Cruise Ship
    ships[4] = ShipFactory::createShip("Ship5", new Date(2005), 800);  // Container Ship
    ships[5] = ShipFactory::createShip("Ship6", new Date(2012), 150);  // Cruise Ship
