// ContainerShip.cpp

#include "ContainerShip.h"
#include <iostream>

ContainerShip::ContainerShip(const char* name, Date* buildYear, double cargoCapacity)
    : Ship(name, buildYear), cargoCapacity(cargoCapacity) {}

void ContainerShip::displayDetails() const {
    std::cout << "Container Ship Name: " << getName() << "\nCargo Capacity: " << cargoCapacity << " tons" << std::endl;
}
