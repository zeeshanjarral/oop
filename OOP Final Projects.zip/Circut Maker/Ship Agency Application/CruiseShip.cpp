// CruiseShip.cpp

#include "CruiseShip.h"
#include <iostream>

CruiseShip::CruiseShip(const char* name, Date* buildYear, int numPassengers)
    : Ship(name, buildYear), numPassengers(numPassengers) {}

void CruiseShip::displayDetails() const {
    std::cout << "Cruise Ship Name: " << getName() << "\nTotal Passengers: " << numPassengers << std::endl;
}
