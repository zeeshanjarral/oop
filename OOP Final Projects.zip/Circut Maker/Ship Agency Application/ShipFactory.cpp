// ShipFactory.cpp

#include "ShipFactory.h"

Ship* ShipFactory::createShip(const char* name, Date* buildYear, int numPassengers) {
    return new CruiseShip(name, buildYear, numPassengers);
}

Ship* ShipFactory::createShip(const char* name, Date* buildYear, double cargoCapacity) {
    return new ContainerShip(name, buildYear, cargoCapacity);
}
