class Date {
private:
    int year;

public:
    Date(int year);

    int getYear() const;
};

class Ship {
private:
    char* name;
    Date* buildYear;

public:
    Ship(const char* name, Date* buildYear);

    virtual ~Ship();

    const char* getName() const;

    const Date* getBuildYear() const;

    virtual void displayDetails() const;
};

