// CruiseShip.h

#ifndef CRUISESHIP_H
#define CRUISESHIP_H

#include "Ship.h"

class CruiseShip : public Ship {
private:
    int numPassengers;

public:
    CruiseShip(const char* name, Date* buildYear, int numPassengers);

    void displayDetails() const override;
};

#endif
