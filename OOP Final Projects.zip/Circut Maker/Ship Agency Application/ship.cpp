// Ship.cpp

#include "Ship.h"
#include <cstring>
#include <iostream>

Date::Date(int year) : year(year) {}

int Date::getYear() const {
    return year;
}

Ship::Ship(const char* name, Date* buildYear) : name(new char[strlen(name) + 1]), buildYear(buildYear) {
    strcpy(this->name, name);
}

Ship::~Ship() {
    delete[] name;
    delete buildYear;
}

const char* Ship::getName() const {
    return name;
}

const Date* Ship::getBuildYear() const {
    return buildYear;
}

void Ship::displayDetails() const {
    std::cout << "Ship Name: " << name << "\nBuild Year: " << buildYear->getYear() << std::endl;
}
