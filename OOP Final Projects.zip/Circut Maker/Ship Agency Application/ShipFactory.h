// ShipFactory.h

#ifndef SHIPFACTORY_H
#define SHIPFACTORY_H

#include "Ship.h"
#include "CruiseShip.h"
#include "ContainerShip.h"

class ShipFactory {
public:
    static Ship* createShip(const char* name, Date* buildYear, int numPassengers);

    static Ship* createShip(const char* name, Date* buildYear, double cargoCapacity);
};

#endif
