// ContainerShip.h

#ifndef CONTAINERSHIP_H
#define CONTAINERSHIP_H

#include "Ship.h"

class ContainerShip : public Ship {
private:
    double cargoCapacity;

public:
    ContainerShip(const char* name, Date* buildYear, double cargoCapacity);

    void displayDetails() const override;
};

#endif
