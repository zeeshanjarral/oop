#include "Question.h"
#include <iostream>
using namespace std;

// Question class implementation
Question::Question(const string& questionStatement) : questionStatement(questionStatement) {}

// MultipleChoiceQuestion class implementation
MultipleChoiceQuestion::MultipleChoiceQuestion(const string& questionStatement, const string options[], int correctOption)
    : Question(questionStatement), correctOption(correctOption) {
    for (int i = 0; i < 4; ++i) {
        this->options[i] = options[i];
    }
}

void MultipleChoiceQuestion::displayQuestion() const {
    cout << "Multiple Choice Question: " << questionStatement << "\n";
    for (int i = 0; i < 4; ++i) {
        cout << i + 1 << ". " << options[i] << endl;
    }
}

bool MultipleChoiceQuestion::checkAnswer(int userResponse) const {
    return (userResponse == correctOption);
}

// TrueFalseQuestion class implementation
TrueFalseQuestion::TrueFalseQuestion(const string& questionStatement, int correctAnswer)
    : Question(questionStatement), correctAnswer(correctAnswer) {}

void TrueFalseQuestion::displayQuestion() const {
    cout << "True/False Question: " << questionStatement << " (True/False)\n";
}

bool TrueFalseQuestion::checkAnswer(int userResponse) const {
    return (userResponse == correctAnswer);
}

// PictureQuestion class implementation
PictureQuestion::PictureQuestion(const string& questionStatement, const string& pictureURL)
    : Question(questionStatement), pictureURL(pictureURL) {}

void PictureQuestion::displayQuestion() const {
    cout << "Picture Question: " << questionStatement << "\n[Display picture here]\n";
}

bool PictureQuestion::checkAnswer(int userResponse) const {
    // Assume a different evaluation method for picture questions
    return (userResponse == 1);  // Modify as needed
}
