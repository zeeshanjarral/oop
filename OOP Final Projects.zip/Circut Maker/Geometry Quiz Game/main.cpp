#include "Question.h"
using namespace std;

int main() {
    // Create instances of each question type
    MultipleChoiceQuestion mcq("What is the capital of France?", {"Paris", "Berlin", "London", "Rome"}, 1);
    TrueFalseQuestion tfq("The Earth is flat.", 0);
    PictureQuestion pq("Identify the shape in the picture.", "URL_or_FilePath");

    // Display and evaluate user responses
    mcq.displayQuestion();
    int mcqResponse;
    cout << "Enter your answer (1-4): ";
    cin >> mcqResponse;
    if (mcq.checkAnswer(mcqResponse)) {
        cout << "Correct!\n\n";
    } else {
        cout << "Incorrect.\n\n";
    }

    tfq.displayQuestion();
    int tfqResponse;
    cout << "Enter your answer (0 for False, 1 for True): ";
    cin >> tfqResponse;
    if (tfq.checkAnswer(tfqResponse)) {
        cout << "Correct!\n\n";
    } else {
        cout << "Incorrect.\n\n";
    }

    pq.displayQuestion();
    int pqResponse;
    cout << "Enter your answer (1 for the correct shape): ";
    cin >> pqResponse;
    if (pq.checkAnswer(pqResponse)) {
        cout << "Correct!\n";
    } else {
        cout << "Incorrect.\n";
    }

    return 0;
}
