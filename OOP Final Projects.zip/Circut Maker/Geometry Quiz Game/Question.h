#include <string>
#include <iostream>
using namespace std;

class Question {
protected:
    string questionStatement;

public:
    Question(const string& questionStatement);
    
    virtual void displayQuestion() const = 0;
    virtual bool checkAnswer(int userResponse) const = 0;
};

class MultipleChoiceQuestion : public Question {
private:
    string options[4];
    int correctOption;

public:
    MultipleChoiceQuestion(const string& questionStatement, const string options[], int correctOption);

    void displayQuestion() const override;
    bool checkAnswer(int userResponse) const override;
};

class TrueFalseQuestion : public Question {
private:
    int correctAnswer;

public:
    TrueFalseQuestion(const string& questionStatement, int correctAnswer);

    void displayQuestion() const override;
    bool checkAnswer(int userResponse) const override;
};

class PictureQuestion : public Question {
private:
    string pictureURL;

public:
    PictureQuestion(const string& questionStatement, const string& pictureURL);

    void displayQuestion() const override;
    bool checkAnswer(int userResponse) const override;
};
