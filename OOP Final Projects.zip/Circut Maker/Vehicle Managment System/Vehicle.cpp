// Vehicle.cpp

#include "Vehicle.h"

Vehicle::Vehicle(const std::string& brand, const std::string& model, bool isAvailable)
    : brand(brand), model(model), isAvailable(isAvailable) {}

Vehicle::~Vehicle() {}

void Vehicle::displayDetails() const {
    std::cout << "Brand: " << brand << "\nModel: " << model << "\nAvailable: " << (isAvailable ? "Yes" : "No") << std::endl;
}

Vehicle& Vehicle::operator=(const Vehicle& other) {
    if (this != &other) {
        brand = other.brand;
        model = other.model;
        isAvailable = other.isAvailable;
    }
    return *this;
}

void Vehicle::performOperation() {
    // Common vehicle operation
    std::cout << "Performing generic vehicle operation." << std::endl;
}
