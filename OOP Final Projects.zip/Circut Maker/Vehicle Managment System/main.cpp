// main.cpp

#include <iostream>
#include "Vehicle.h"
#include "CarVehicle.h"
#include "MotorcycleVehicle.h"

int main() {
    // Get user input for CarVehicle
    std::string carBrand, carModel;
    int carPassengerCapacity;
    bool carAvailability;
    std::cout << "Enter Car Brand: ";
    std::cin >> carBrand;
    std::cout << "Enter Car Model: ";
    std::cin >> carModel;
    std::cout << "Enter Car Passenger Capacity: ";
    std::cin >> carPassengerCapacity;
    std::cout << "Is Car Available? (1 for Yes, 0 for No): ";
    std::cin >> carAvailability;

    // Create instance of CarVehicle
    CarVehicle sedan(carBrand, carModel, carAvailability, carPassengerCapacity);

    // Get user input for MotorcycleVehicle
    std::string motorcycleBrand, motorcycleModel;
    bool motorcycleHasSideCar, motorcycleAvailability;
    std::cout << "\nEnter Motorcycle Brand: ";
    std::cin >> motorcycleBrand;
    std::cout << "Enter Motorcycle Model: ";
    std::cin >> motorcycleModel;
    std::cout << "Does Motorcycle Have Sidecar? (1 for Yes, 0 for No): ";
    std::cin >> motorcycleHasSideCar;
    std::cout << "Is Motorcycle Available? (1 for Yes, 0 for No): ";
    std::cin >> motorcycleAvailability;

    // Create instance of MotorcycleVehicle
    MotorcycleVehicle bike(motorcycleBrand, motorcycleModel, motorcycleAvailability, motorcycleHasSideCar);

    // Display details for each vehicle using base class pointer polymorphically
    std::cout << "\nVehicle Details:" << std::endl;

    // Using base class pointer polymorphically
    Vehicle* ptr1 = &sedan;
    ptr1->displayDetails();

    std::cout << "\nVehicle Details:" << std::endl;

    // Using base class pointer polymorphically
    Vehicle* ptr2 = &bike;
    ptr2->displayDetails();

    // Perform operations for each vehicle
    std::cout << "\nPerforming Operation for Car:" << std::endl;
    ptr1->performOperation();

    std::cout << "\nPerforming Operation for Motorcycle:" << std::endl;
    ptr2->performOperation();

    // Use assignment operator and display copied vehicle details
    CarVehicle copiedSedan("Copied Car", "", false, 0);
    MotorcycleVehicle copiedBike("Copied Motorcycle", "", false, false);

    copiedSedan = sedan;
    copiedBike = bike;

    std::cout << "\nCopied Car Details:" << std::endl;
    // Using base class pointer polymorphically
    Vehicle* ptr3 = &copiedSedan;
    ptr3->displayDetails();

    std::cout << "\nCopied Motorcycle Details:" << std::endl;
    // Using base class pointer polymorphically
    Vehicle* ptr4 = &copiedBike;
    ptr4->displayDetails();

    return 0;
}
