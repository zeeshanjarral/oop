// MotorcycleVehicle.cpp

#include "MotorcycleVehicle.h"

MotorcycleVehicle::MotorcycleVehicle(const std::string& brand, const std::string& model, bool isAvailable, bool hasSideCar)
    : Vehicle(brand, model, isAvailable), hasSideCar(hasSideCar) {}

void MotorcycleVehicle::displayDetails() const {
    Vehicle::displayDetails();
    std::cout << "Has Sidecar: " << (hasSideCar ? "Yes" : "No") << std::endl;
}

Vehicle& MotorcycleVehicle::operator=(const Vehicle& other) {
    if (this != &other) {
        Vehicle::operator=(other);
        const MotorcycleVehicle& otherMotorcycle = dynamic_cast<const MotorcycleVehicle&>(other);
        hasSideCar = otherMotorcycle.hasSideCar;
    }
    return *this;
}

void MotorcycleVehicle::performOperation() {
    // Specific operation for MotorcycleVehicle
    std::cout << "Performing motorcycle-specific operation." << std::endl;
}
