#include <iostream>
#include <string>

class Vehicle {
public:
    Vehicle(const std::string& brand, const std::string& model, bool isAvailable);
    virtual ~Vehicle();

    virtual void displayDetails() const;
    virtual Vehicle& operator=(const Vehicle& other);
    virtual void performOperation();

protected:
    std::string brand;
    std::string model;
    bool isAvailable;
};