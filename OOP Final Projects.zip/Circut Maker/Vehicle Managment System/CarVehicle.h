// CarVehicle.h

#ifndef CAR_VEHICLE_H
#define CAR_VEHICLE_H

#include "Vehicle.h"

class CarVehicle : public Vehicle {
public:
    CarVehicle(const std::string& brand, const std::string& model, bool isAvailable, int passengerCapacity);
    void displayDetails() const override;
    Vehicle& operator=(const Vehicle& other) override;
    void performOperation() override;

private:
    int passengerCapacity;
};

#endif
