// CarVehicle.cpp

#include "CarVehicle.h"

CarVehicle::CarVehicle(const std::string& brand, const std::string& model, bool isAvailable, int passengerCapacity)
    : Vehicle(brand, model, isAvailable), passengerCapacity(passengerCapacity) {}

void CarVehicle::displayDetails() const {
    Vehicle::displayDetails();
    std::cout << "Passenger Capacity: " << passengerCapacity << std::endl;
}

Vehicle& CarVehicle::operator=(const Vehicle& other) {
    if (this != &other) {
        Vehicle::operator=(other);
        const CarVehicle& otherCar = dynamic_cast<const CarVehicle&>(other);
        passengerCapacity = otherCar.passengerCapacity;
    }
    return *this;
}

void CarVehicle::performOperation() {
    // Specific operation for CarVehicle
    std::cout << "Performing car-specific operation." << std::endl;
}
