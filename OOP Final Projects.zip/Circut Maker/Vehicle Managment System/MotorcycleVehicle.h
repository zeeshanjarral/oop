#include "Vehicle.h"

class MotorcycleVehicle : public Vehicle {
public:
    MotorcycleVehicle(const std::string& brand, const std::string& model, bool isAvailable, bool hasSideCar);
    void displayDetails() const override;
    Vehicle& operator=(const Vehicle& other) override;
    void performOperation() override;

private:
    bool hasSideCar;
};
