#include <iostream>
#include "SavingAccount.h"

int main() {
    SavingAccount savingAccount(1000, 0.05);
    savingAccount.deposit(500);
    savingAccount.calculateInterest(2);
    

    return 0;
}
