#include "Account.h"

class SavingAccount : public Account {
public:
    SavingAccount(double initialBalance, double interestRate);
    ~SavingAccount();

    void withdraw(double amount) override;
    void calculateInterest(double years);

private:
    double interestRate;
};

