class Account {
public:
    Account(double initialBalance);
    virtual ~Account();

    virtual void deposit(double amount);
    virtual void withdraw(double amount) = 0;
    double getBalance() const;

protected:
    double balance;
};