#include "SavingAccount.h"

SavingAccount::SavingAccount(double initialBalance, double interestRate)
    : Account(initialBalance), interestRate(interestRate) {}

SavingAccount::~SavingAccount() {}

void SavingAccount::withdraw(double amount) {
}

void SavingAccount::calculateInterest(double years) {
    double interest = balance * interestRate * years;
    balance += interest;
}
