#include "Account.h"

Account::Account(double initialBalance) : balance(initialBalance) {}

Account::~Account() {}

void Account::deposit(double amount) {
    balance += amount;
}

double Account::getBalance() const {
    return balance;
}
