#ifndef BAKEWARE_H
#define BAKEWARE_H

#include "Kitchenware.h"

class Bakeware : public Kitchenware {
public:
    Bakeware(const std::string& name, double price);

    virtual ~Bakeware();

    virtual void print() const override;
};

#endif // BAKEWARE_H
