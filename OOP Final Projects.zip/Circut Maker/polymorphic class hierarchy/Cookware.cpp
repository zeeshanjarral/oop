#include "Cookware.h"

Cookware::Cookware(const std::string& name, double price) : Kitchenware(name, price) {
}

Cookware::~Cookware() {
    std::cout << "~Cookware()" << std::endl;
}

void Cookware::print() const {
    std::cout << "Cookware price = $" << price << std::endl;
}
