#ifndef KITCHENWARE_H
#define KITCHENWARE_H

#include <iostream>
#include <string>

class Kitchenware {
public:
    Kitchenware(const std::string& name, double price);

    virtual ~Kitchenware();

    static double getTotalCost();

    virtual void print() const = 0;

protected:
    std::string name;
    double price;
    static double totalCost;
};

#endif // KITCHENWARE_H
