#ifndef CUTLERY_H
#define CUTLERY_H

#include "Kitchenware.h"

class Cutlery : public Kitchenware {
public:
    Cutlery(const std::string& name, double price);

    virtual ~Cutlery();

    virtual void print() const override;
};

#endif // CUTLERY_H
