#ifndef DISHWARE_H
#define DISHWARE_H

#include "Kitchenware.h"

class Dishware : public Kitchenware {
public:
    Dishware(const std::string& name, double price);

    virtual ~Dishware();

    virtual void print() const override;
};

#endif // DISHWARE_H
