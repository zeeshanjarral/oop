#include "Cutlery.h"

Cutlery::Cutlery(const std::string& name, double price) : Kitchenware(name, price) {
}

Cutlery::~Cutlery() {
    std::cout << "~Cutlery()" << std::endl;
}

void Cutlery::print() const {
    std::cout << "Cutlery price = $" << price << std::endl;
}
