#include "Bakeware.h"

Bakeware::Bakeware(const std::string& name, double price) : Kitchenware(name, price) {
}

Bakeware::~Bakeware() {
    std::cout << "~Bakeware()" << std::endl;
}

void Bakeware::print() const {
    std::cout << "Bakeware price = $" << price << std::endl;
}
