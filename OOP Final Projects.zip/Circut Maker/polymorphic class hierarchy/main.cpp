#include "Kitchenware.h"
#include "Cookware.h"
#include "Cutlery.h"
#include "Dishware.h"
#include "Bakeware.h"

int main() {
    const int MAX_ITEMS = 4;
    Kitchenware *items[MAX_ITEMS];

    items[0] = new Cookware("Pot", 20.0);
    items[1] = new Cutlery("Fork", 1.5);
    items[2] = new Dishware("Plate", 5.0);
    items[3] = new Bakeware("Baking Tray", 15.0);

    std::cout << "Cost of all items: $" << Kitchenware::getTotalCost() << std::endl;

    for (int i = 0; i < MAX_ITEMS; i++)
        items[i]->print();

    for (int i = 0; i < MAX_ITEMS; i++)
        delete items[i];

    return 0;
}
