#ifndef COOKWARE_H
#define COOKWARE_H

#include "Kitchenware.h"

class Cookware : public Kitchenware {
public:
    Cookware(const std::string& name, double price);

    virtual ~Cookware();

    virtual void print() const override;
};

#endif // COOKWARE_H
