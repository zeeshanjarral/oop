#include "Dishware.h"

Dishware::Dishware(const std::string& name, double price) : Kitchenware(name, price) {
}

Dishware::~Dishware() {
    std::cout << "~Dishware()" << std::endl;
}

void Dishware::print() const {
    std::cout << "Dishware price = $" << price << std::endl;
}
