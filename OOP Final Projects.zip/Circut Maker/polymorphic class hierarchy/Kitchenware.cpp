#include "Kitchenware.h"

double Kitchenware::totalCost = 0.0;

Kitchenware::Kitchenware(const std::string& name, double price) : name(name), price(price) {
    totalCost += price;
}

Kitchenware::~Kitchenware() {
    totalCost -= price;
}

double Kitchenware::getTotalCost() {
    return totalCost;
}
