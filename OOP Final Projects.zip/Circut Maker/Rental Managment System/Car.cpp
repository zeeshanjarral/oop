#include "Car.h"
#include <iostream>

Car::Car() : Vehicle(), numDoors(4) {}

Car::Car(std::string _brand, std::string _model, int _numDoors) : Vehicle(_brand, _model), numDoors(_numDoors) {}

void Car::displayInfo() {
    Vehicle::displayInfo();
    std::cout << ", Number of Doors: " << numDoors;
}
