#include "Vehicle.h"

class Car : public Vehicle {
private:
    int numDoors;

public:
    Car();
    Car(std::string _brand, std::string _model, int _numDoors);
    void displayInfo() override;
};