#include "Vehicle.h"
#include "Car.h"
#include <iostream>

int main() {
    Car sedan("Toyota", "Camry", 4);
    Motorcycle bike("Harley-Davidson", "Sportster", 2);
    Truck pickup("Ford", "F-150", 2.5);

    RentalAgency rentalAgency;
    rentalAgency.addVehicle(&sedan);
    rentalAgency.addVehicle(&bike);
    rentalAgency.addVehicle(&pickup);

    rentalAgency.displayRentalInfo();

    return 0;
}
