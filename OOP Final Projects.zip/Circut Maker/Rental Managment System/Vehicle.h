#include <string>

class Vehicle {
private:
    std::string brand;
    std::string model;

public:
    Vehicle();
    Vehicle(std::string _brand, std::string _model);
    virtual void displayInfo();
};