#include "Vehicle.h"
#include <iostream>

Vehicle::Vehicle() : brand("Unknown"), model("Not specified") {}

Vehicle::Vehicle(std::string _brand, std::string _model) : brand(_brand), model(_model) {}

void Vehicle::displayInfo() {
    std::cout << "Brand: " << brand << ", Model: " << model;
}
