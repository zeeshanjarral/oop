#include "ZooSystem.h"
#include <cstring>

// Animal class implementation
Animal::Animal() {
    std::strcpy(name, "Unknown");
    std::strcpy(type, "Animal");
}

Animal::Animal(const char* name, const char* type) {
    std::strcpy(this->name, name);
    std::strcpy(this->type, type);
}

Animal::~Animal() {}

void Animal::displayInfo() {
    std::cout << "Name: " << name << "\nType: " << type << std::endl;
}

// Mammal class implementation
Mammal::Mammal() : Animal() {
    std::strcpy(furColor, "Not specified");
}

Mammal::Mammal(const char* name, const char* type, const char* furColor)
    : Animal(name, type) {
    std::strcpy(this->furColor, furColor);
}

void Mammal::displayInfo() {
    Animal::displayInfo();
    std::cout << "Fur Color: " << furColor << std::endl;
}

// Bird class implementation
Bird::Bird() : Animal(), wingSpan(0.0) {}

Bird::Bird(const char* name, const char* type, double wingSpan)
    : Animal(name, type), wingSpan(wingSpan) {}

void Bird::displayInfo() {
    Animal::displayInfo();
    std::cout << "Wing Span: " << wingSpan << " meters" << std::endl;
}

// Fish class implementation
Fish::Fish() : Animal() {
    std::strcpy(scaleColor, "Not specified");
}

Fish::Fish(const char* name, const char* type, const char* scaleColor)
    : Animal(name, type) {
    std::strcpy(this->scaleColor, scaleColor);
}

void Fish::displayInfo() {
    Animal::displayInfo();
    std::cout << "Scale Color: " << scaleColor << std::endl;
}

// Zoo class implementation
Zoo::Zoo() : animalCount(0) {}

Zoo::~Zoo() {
    for (int i = 0; i < animalCount; ++i) {
        delete animals[i];
    }
}

void Zoo::addAnimal(Animal* newAnimal) {
    if (animalCount < 50) {
        animals[animalCount++] = newAnimal;
    }
}

void Zoo::displayZooInfo() {
    for (int i = 0; i < animalCount; ++i) {
        animals[i]->displayInfo();
        std::cout << "-------------" << std::endl;
    }
}
