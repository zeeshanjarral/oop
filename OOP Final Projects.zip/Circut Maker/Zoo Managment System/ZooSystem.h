#include <iostream>

class Animal {
private:
    char name[50];
    char type[20];

public:
    Animal();
    Animal(const char* name, const char* type);
    virtual ~Animal();

    virtual void displayInfo();
};

class Mammal : public Animal {
private:
    char furColor[20];

public:
    Mammal();
    Mammal(const char* name, const char* type, const char* furColor);

    void displayInfo() override;
};

class Bird : public Animal {
private:
    double wingSpan;

public:
    Bird();
    Bird(const char* name, const char* type, double wingSpan);

    void displayInfo() override;
};

class Fish : public Animal {
private:
    char scaleColor[20];

public:
    Fish();
    Fish(const char* name, const char* type, const char* scaleColor);

    void displayInfo() override;
};

class Zoo {
private:
    Animal* animals[50];
    int animalCount;

public:
    Zoo();
    ~Zoo();

    void addAnimal(Animal* newAnimal);
    void displayZooInfo();
};