#include "ZooSystem.h"

int main() {
    Mammal lion("Lion", "Mammal", "Golden");
    Bird eagle("Eagle", "Bird", 2.5);
    Fish salmon("Salmon", "Fish", "Silver");

    Zoo zoo;
    zoo.addAnimal(&lion);
    zoo.addAnimal(&eagle);
    zoo.addAnimal(&salmon);

    zoo.displayZooInfo();

    return 0;
}
