#include <iostream>
#include <string>

class CheckIn
{
private:
public:
    CheckIn();
};

