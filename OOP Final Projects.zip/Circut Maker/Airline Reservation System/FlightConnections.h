#include <iostream>
#include <string>

class FlightConnections
{
private:
public:
    FlightConnections();
};