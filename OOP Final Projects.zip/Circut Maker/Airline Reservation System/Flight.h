// Flight.h

#ifndef FLIGHT_H
#define FLIGHT_H

#include <iostream>
#include <string>

struct Flight {
    int flightNumber;
    std::string departureTime;
    std::string arrivalTime;
    int availableSeats;
    // Add other flight details as needed
};

#endif // FLIGHT_H
