// main.cpp

#include "AirlineReservationSystem.h"

int main() {
    AirlineReservationSystem airlineSystem;

    // Example usage
    airlineSystem.addFlight(101, "10:00 AM", "12:00 PM", 150);
    airlineSystem.updateFlight(101, "11:00 AM", "1:00 PM", 120);
    airlineSystem.displayFlightDetails(101);

    return 0;
}
