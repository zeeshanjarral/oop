#include <iostream>
#include <string>

class FlightHistory
{
private:
public:
    FlightHistory();
    
};

