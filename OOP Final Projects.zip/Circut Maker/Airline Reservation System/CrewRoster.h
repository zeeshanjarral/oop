#include <iostream>
#include <string>

class CrewRoster
{
private:
public:
    CrewRoster();
};

