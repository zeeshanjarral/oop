// AirlineReservationSystem.h

#ifndef AIRLINERESERVATIONSYSTEM_H
#define AIRLINERESERVATIONSYSTEM_H

#include <iostream>
#include <vector>
#include <list>
#include "Flight.h"

class AirlineReservationSystem {
public:
    void addFlight(int flightNumber, std::string departureTime, std::string arrivalTime, int availableSeats);
    void updateFlight(int flightNumber, std::string departureTime, std::string arrivalTime, int availableSeats);
    void displayFlightDetails(int flightNumber);
    // Add other function declarations as needed

private:
    std::vector<Flight> flights;
    // Add other data structures as needed
    // Add private helper functions as needed
};

#endif // AIRLINERESERVATIONSYSTEM_H
