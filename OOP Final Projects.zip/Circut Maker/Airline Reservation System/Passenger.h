#include <iostream>
#include <string>

class Passenger
{
private:
    string name;
    string bookingReference;

public:
    Passenger();
    Passenger(string passengerName, string reference);

 
    string getName() const;
    string getBookingReference() const;

   
    void setName(string passengerName);
    void setBookingReference(string reference);

   
    void displayPassengerDetails() const;
    
};

