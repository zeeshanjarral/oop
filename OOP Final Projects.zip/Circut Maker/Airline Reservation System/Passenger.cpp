#include "Passenger.h"
using namespace std;

Passenger::Passenger()
{
    name = "";
    bookingReference = "";
}

Passenger::Passenger(string passengerName, string reference)
{
    name = passengerName;
    bookingReference = reference;
}

string Passenger::getName() const
{
    return name;
}

string Passenger::getBookingReference() const
{
    return bookingReference;
}

void Passenger::setName(string passengerName)
{
    name = passengerName;
}

void Passenger::setBookingReference(string reference)
{
    bookingReference = reference;
}

void Passenger::displayPassengerDetails() const
{
    cout << "Passenger Name: " << name << endl;
    cout << "Booking Reference: " << bookingReference << endl;
}
