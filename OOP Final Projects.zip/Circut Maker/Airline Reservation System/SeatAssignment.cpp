#include <iostream>
#include <string>

class SeatAssignment
{
private:
public:
    SeatAssignment();
};