#include "Flight.h"

Flight::Flight()
{
    flightNumber = "";
    departureTime = "";
    arrivalTime = "";
    availableSeats = 0;
}

Flight::Flight(string number, string departTime, string arriveTime, int seats)
{
    flightNumber = number;
    departureTime = departTime;
    arrivalTime = arriveTime;
    availableSeats = seats;
}

string Flight::getFlightNumber() const
{
    return flightNumber;
}

string Flight::getDepartureTime() const
{
    return departureTime;
}

string Flight::getArrivalTime() const
{
    return arrivalTime;
}

int Flight::getAvailableSeats() const
{
    return availableSeats;
}

void Flight::setFlightNumber(string number)
{
    flightNumber = number;
}

void Flight::setDepartureTime(string departTime)
{
    departureTime = departTime;
}

void Flight::setArrivalTime(string arriveTime)
{
    arrivalTime = arriveTime;
}

void Flight::setAvailableSeats(int seats)
{
    availableSeats = seats;
}

void Flight::displayFlightDetails() const
{
    cout << "Flight Number: " << flightNumber << endl;
    cout << "Departure Time: " << departureTime << endl;
    cout << "Arrival Time: " << arrivalTime << endl;
    cout << "Available Seats: " << availableSeats << endl;
}
